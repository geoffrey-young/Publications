package Cookbook::LanguagePriority;

use 5.006;
use DynaLoader;

our @ISA = qw(DynaLoader);
our $VERSION = '0.01';

__PACKAGE__->bootstrap($VERSION);

1;
