# file t/conf/modperl_extra.pl
eval "require Apache::Filter";
1;
